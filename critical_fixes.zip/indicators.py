"""
core/indicators.py
==================
Technical indicator computation for the Sovereign Engine.

FIX — _supertrend_vectorised bar-0 initialisation (v14.1)
----------------------------------------------------------
The original code hardcoded ``trend_up[0] = True`` regardless of where
the first bar's close sits relative to the computed bands.  For any
instrument that opens in a downtrend the first ``REGIME_CONFIRM_BARS``
outputs were therefore wrong, which cascaded into incorrect Supertrend
signals and biased the trend factor score.

Correct behaviour: on bar 0, if close >= final_lower → uptrend,
otherwise → downtrend.  The active band (st[0]) is set accordingly so
that the loop on bar 1 reads the right prior-bar band.
"""

import pandas as pd
import numpy as np


def _true_range(df: pd.DataFrame) -> pd.Series:
    hl  = df["High"] - df["Low"]
    hpc = (df["High"] - df["Close"].shift(1)).abs()
    lpc = (df["Low"]  - df["Close"].shift(1)).abs()
    return pd.concat([hl, hpc, lpc], axis=1).max(axis=1)


def _wilder(s: pd.Series, period: int) -> pd.Series:
    return s.ewm(alpha=1.0 / period, min_periods=period, adjust=False).mean()


def _supertrend_vectorised(
    df: pd.DataFrame, period: int, mult: float
) -> tuple[np.ndarray, np.ndarray]:
    """
    Vectorised Supertrend — returns (supertrend_line, trend_up_mask).

    Bar-0 fix
    ---------
    The Wilder ATR requires ``period`` bars to warm up, so ``final_upper``
    and ``final_lower`` are NaN for the first ``period - 1`` bars.

    The original code hardcoded ``trend_up[0] = True`` and set
    ``st[0] = final_upper[0]`` regardless of price position.  This was
    wrong in two ways:

      1. Bar 0 is NaN — comparing NaN to close is always False, so the
         carry-forward loop silently propagated a NaN band for the entire
         warmup window.
      2. The first valid bar inherited the wrong prior-bar band direction,
         producing incorrect signals for at least ``REGIME_CONFIRM_BARS``
         bars on any instrument opening in a downtrend.

    Fix: scan forward to the first bar where both bands are finite.  Seed
    ``trend_up`` there from ``close >= final_lower`` (the correct Supertrend
    definition).  All bars before that seed remain NaN in ``st`` — they
    are stripped by ``add_indicators``'s ``dropna`` call anyway.
    """
    tr  = _true_range(df)
    atr = _wilder(tr, period)
    hl2 = (df["High"] + df["Low"]) / 2
    close = df["Close"].values
    n = len(close)

    final_upper = (hl2 + mult * atr).values.copy()
    final_lower = (hl2 - mult * atr).values.copy()

    # ── Band carry-forward (bars 1..n-1) ─────────────────────────────────────
    for i in range(1, n):
        if np.isnan(final_upper[i - 1]) or np.isnan(final_lower[i - 1]):
            continue                        # warmup period — skip carry
        final_upper[i] = (
            final_upper[i]
            if close[i - 1] > final_upper[i - 1]
            else min(final_upper[i], final_upper[i - 1])
        )
        final_lower[i] = (
            final_lower[i]
            if close[i - 1] < final_lower[i - 1]
            else max(final_lower[i], final_lower[i - 1])
        )

    # ── Trend direction array ─────────────────────────────────────────────────
    trend_up = np.empty(n, dtype=bool)
    st       = np.full(n, np.nan)

    # FIX: find first bar where both bands are valid and seed from price.
    seed = -1
    for i in range(n):
        if not (np.isnan(final_upper[i]) or np.isnan(final_lower[i])):
            seed = i
            break

    if seed == -1:
        # Entire series is NaN (shouldn't happen with real data, but be safe).
        return st, trend_up

    trend_up[seed] = close[seed] >= final_lower[seed]
    st[seed]       = final_lower[seed] if trend_up[seed] else final_upper[seed]

    # ── Loop bars seed+1..n-1 ─────────────────────────────────────────────────
    for i in range(seed + 1, n):
        if st[i - 1] == final_lower[i - 1]:
            trend_up[i] = close[i] >= final_lower[i]
        else:
            trend_up[i] = close[i] > final_upper[i]
        st[i] = final_lower[i] if trend_up[i] else final_upper[i]

    return st, trend_up

def add_indicators(df: pd.DataFrame, config) -> pd.DataFrame:  # noqa: C901
    """
    Compute all technical indicators and attach them to a copy of ``df``.

    Data-quality contract
    ---------------------
    ``ATR_Pctile`` requires 50+ bars of ATR history (rolling 252, min 50).
    When fewer bars are available the column contains ``NaN`` for early rows.
    The ``passes_data_quality()`` gate in ``scorer.py`` checks for this
    explicitly — do NOT fill ``ATR_Pctile`` NaN with a neutral value (50)
    here, because that silently hides data-sparse tickers and lets them pass
    the volatility factor check unpenalised.

    ``ATR_50_mean`` is similarly ``NaN`` for the first 49 bars.  Both
    columns are intentionally left as ``NaN`` so callers can distinguish
    "no data" from "mid-range data".
    """
    df = df.copy()
    c = df["Close"]

    df["EMA_20"] = c.ewm(span=20, adjust=False).mean()
    df["EMA_50"] = c.ewm(span=50, adjust=False).mean()
    df["EMA_200"] = c.ewm(span=200, adjust=False).mean()

    delta = c.diff()
    avg_gain = _wilder(delta.clip(lower=0), 14)
    avg_loss = _wilder((-delta.clip(upper=0)), 14)
    rs_s = np.where(avg_loss == 0, np.inf, avg_gain / avg_loss)
    df["RSI"] = 100 - (100 / (1 + rs_s))

    # StochRSI
    rsi_s     = df["RSI"]
    stoch_len = 14
    rsi_lo    = rsi_s.rolling(stoch_len).min()
    rsi_hi    = rsi_s.rolling(stoch_len).max()
    stoch_rsi = (rsi_s - rsi_lo) / (rsi_hi - rsi_lo + 1e-9)
    df["StochRSI_K"] = stoch_rsi.rolling(3).mean() * 100
    df["StochRSI_D"] = df["StochRSI_K"].rolling(3).mean()

    tr = _true_range(df)
    df["ATR"] = _wilder(tr, 14)
    df["ATR_50_mean"] = df["ATR"].rolling(50).mean()
    df["ATR_Pctile"] = df["ATR"].rolling(252, min_periods=50).rank(pct=True) * 100

    st_vals, trend_up = _supertrend_vectorised(df, config.SUPER_PERIOD, config.SUPER_MULT)
    df["Supertrend"] = st_vals
    df["Super_Up"] = trend_up

    adx_p = config.ADX_PERIOD
    h, l_ = df["High"].values, df["Low"].values
    pdm = np.where((h[1:]-h[:-1]>l_[:-1]-l_[1:])&(h[1:]-h[:-1]>0), h[1:]-h[:-1], 0.0)
    ndm = np.where((l_[:-1]-l_[1:]>h[1:]-h[:-1])&(l_[:-1]-l_[1:]>0), l_[:-1]-l_[1:], 0.0)
    pdm = pd.Series(np.insert(pdm, 0, 0.0), index=df.index)
    ndm = pd.Series(np.insert(ndm, 0, 0.0), index=df.index)
    tr_s = pd.Series(tr.values, index=df.index)
    pdm_s = _wilder(pdm, adx_p); ndm_s = _wilder(ndm, adx_p)
    tr_sm = _wilder(tr_s, adx_p).replace(0, np.nan)
    pdi = 100*pdm_s/tr_sm; ndi = 100*ndm_s/tr_sm
    dx = 100*(pdi-ndi).abs()/(pdi+ndi).replace(0, np.nan)
    df["ADX"] = _wilder(dx, adx_p)

    ema12 = c.ewm(span=12, adjust=False).mean()
    ema26 = c.ewm(span=26, adjust=False).mean()
    ml = ema12 - ema26
    df["MACD_Hist"] = ml - ml.ewm(span=9, adjust=False).mean()

    # Bollinger Bands (Fix for BB_Width/BB_Squeeze dead factors)
    bb_period, bb_std = 20, 2.0
    bb_mid = c.rolling(bb_period).mean()
    bb_sd  = c.rolling(bb_period).std(ddof=0)
    df["BB_Upper"]  = bb_mid + bb_std * bb_sd
    df["BB_Lower"]  = bb_mid - bb_std * bb_sd
    df["BB_Width"]  = (df["BB_Upper"] - df["BB_Lower"]) / bb_mid
    bw_avg          = df["BB_Width"].rolling(50).mean()
    df["BB_Squeeze"] = df["BB_Width"] < (bw_avg * 0.85)

    df["Vol_Avg_20"] = df["Volume"].rolling(20).mean()
    df["RVol_20"] = c.pct_change().rolling(20).std()
    df["Turnover_Avg_20"] = (c * df["Volume"]).rolling(20).mean()
    df["Up_Day"] = (c > df["Open"]).astype(int)
    df["Dn_Day"] = (c < df["Open"]).astype(int)
    
    df.dropna(subset=["EMA_20","EMA_50","EMA_200","RSI","ATR","ADX","Vol_Avg_20","MACD_Hist"], inplace=True)
    return df
